import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';

interface ParqQuestion {
  id: number;
  questionText: string;
  userAnswer: boolean | null;
}

@Component({
  selector: 'app-submit-form',
  templateUrl: './submit-form.page.html',
  styleUrls: ['./submit-form.page.scss'],
  standalone: false
})
export class SubmitFormPage implements OnInit {
  currentSectionType: string = 'general';
  stepIndicatorText: string = 'Step 1 of 5';
  activeQuestionsList: ParqQuestion[] = [];

  generalQuestions: ParqQuestion[] = [
    {
      id: 1,
      questionText:
        'Has your doctor ever said that you have a heart condition OR high blood pressure?',
      userAnswer: null
    },
    {
      id: 2,
      questionText:
        'Do you feel pain in your chest at rest, during daily activities, OR when you do physical activity?',
      userAnswer: null
    },
    {
      id: 3,
      questionText:
        'Do you lose balance because of dizziness OR have you lost consciousness in the last 12 months?',
      userAnswer: null
    },
    {
      id: 4,
      questionText:
        'Do you have a bone or joint problem that could be made worse by a change in your physical activity?',
      userAnswer: null
    },
    {
      id: 5,
      questionText:
        'Is your doctor currently prescribing drugs for your blood pressure or heart condition?',
      userAnswer: null
    },
    {
      id: 6,
      questionText:
        'Do you know of any other reason why you should not do physical activity?',
      userAnswer: null
    },
    {
      id: 7,
      questionText:
        'Have you recently undergone surgical operations that restrict intense movement?',
      userAnswer: null
    }
  ];

  medicalQuestions: ParqQuestion[] = [
    {
      id: 1,
      questionText:
        'Do you have a history of chronic respiratory conditions or metabolic diseases that require regular therapy?',
      userAnswer: null
    },
    {
      id: 2,
      questionText:
        'Are you currently taking any regular medical treatment unmentioned in general health screening?',
      userAnswer: null
    },
    {
      id: 3,
      questionText:
        'Has a medical practitioner restricted you from participating in lifting or high-intensity intervals?',
      userAnswer: null
    }
  ];

  declarationQuestions: ParqQuestion[] = [
    {
      id: 1,
      questionText:
        'I confirm that all the information provided regarding my health status is accurate and correct to my best knowledge.',
      userAnswer: null
    },
    {
      id: 2,
      questionText:
        'I understand that embarking on an exercise regimen contains natural minor injury risks, and I accept liability controls.',
      userAnswer: null
    }
  ];

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private location: Location,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.route.queryParams.subscribe(params => {
      const type = params['type'];

      if (
        type === 'general' ||
        type === 'medical' ||
        type === 'declaration'
      ) {
        this.currentSectionType = type;
      }

      this.setupActiveViewStructure();
    });
  }

  setupActiveViewStructure(): void {
    if (this.currentSectionType === 'medical') {
      this.stepIndicatorText = 'Step 2 of 5';
      this.activeQuestionsList = this.medicalQuestions;
    } else if (this.currentSectionType === 'declaration') {
      this.stepIndicatorText = 'Step 3 of 5';
      this.activeQuestionsList = this.declarationQuestions;
    } else {
      this.stepIndicatorText = 'Step 1 of 5';
      this.activeQuestionsList = this.generalQuestions;
    }

    this.cdr.detectChanges();
  }

  back(): void {
    this.location.back();
  }

  answerQuestion(index: number, answer: boolean): void {
    this.activeQuestionsList[index].userAnswer = answer;
    this.cdr.detectChanges();
  }

  calculateProgressPercentage(): number {
    if (this.activeQuestionsList.length === 0) {
      return 0;
    }

    const answeredCount = this.activeQuestionsList.filter(
      question => question.userAnswer !== null
    ).length;

    return (answeredCount / this.activeQuestionsList.length) * 100;
  }

  submitAssessmentAnswers(): void {
    const totalAnswered = this.activeQuestionsList.filter(
      question => question.userAnswer !== null
    ).length;

    if (totalAnswered < this.activeQuestionsList.length) {
      alert(
        `Please answer all questions before continuing. (${totalAnswered}/${this.activeQuestionsList.length} completed)`
      );
      return;
    }

    alert(
      `Success: ${this.currentSectionType} section completed locally.`
    );

    this.router.navigate(['/forms']);
  }
}