import { Component, OnInit } from '@angular/core';
import { NavController } from '@ionic/angular';
import { User } from '../user';

interface ProfileDataset {
  name: string;
  email: string;
  avatar: string;
  experience: string;
  rating: number;
  mobile: string;
  location: string;
  birthdate: string;
  gender: string;
  specialties: string[];
  certificates: string[];
  tags: string[];
  about: string;
}

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.page.html',
  styleUrls: ['./my-profile.page.scss'],
  standalone: false
})
export class MyProfilePage implements OnInit {
  
  public isEditing: boolean = false;
  public isGenderDropdownOpen: boolean = false;
    public isHeaderMenuOpen: boolean = false; // NEW
    profileCompletion = 40;

  public profileData: ProfileDataset = {
    name: 'Hany Rambod',
    email: 'hanyrambod07@gmail.com',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=256&auto=format&fit=crop',
    experience: '5Years',
    rating: 4.5,
    mobile: '9876543210',
    location: 'Andheri (E)',
    birthdate: '29/02/2024',
    gender: 'Male',
    specialties: [
      'lose weight and get tonned',
      'Gain flexibility',
      'Build Muscles and boost stamina',
      'Post-physical therapy recovery.',
      'Improving mobility',
      'diet & lifestyle changes'
    ],
    certificates: [
      'https://images.unsplash.com/photo-1589330694653-ded6df03f754?q=80&w=150&auto=format&fit=crop',
      'https://images.unsplash.com/photo-1589330694653-ded6df03f754?q=80&w=150&auto=format&fit=crop'
    ],
    tags: ['Strength', 'Circuits', 'Cardio', 'Nutrition'],
    about: 'Hany believes that by unlocking the body and the mind trough regular strength practice everything else in life becomes...'
  };

  constructor(private navCtrl: NavController,private userService:User) {}

  ngOnInit(): void {}

  public toggleProfileMode(): void {
    this.isEditing = !this.isEditing;
  }

  public toggleGenderDropdown(): void {
    this.isGenderDropdownOpen = !this.isGenderDropdownOpen;
  }

  public selectGenderValue(chosenGender: string): void {
    this.profileData.gender = chosenGender;
    this.isGenderDropdownOpen = false;
  }
  // --- HEADER 3-DOT MENU ---
  public toggleHeaderMenu(): void {
    this.isHeaderMenuOpen = !this.isHeaderMenuOpen;
  }

  public closeHeaderMenu(): void {
    this.isHeaderMenuOpen = false;
  }

  public onHelpClick(): void {
    this.closeHeaderMenu();
    this.navCtrl.navigateForward('/help');
    // or open a support modal / external link, whatever your app uses
  }

  public onLogoutClick(): void {
    this.closeHeaderMenu();
    this.userService.clearCurrentUser();  // 🔥 important
      // Clear user data from storage
    this.clearUserData();

    // Clear any stored session/auth data here, e.g.:
    // localStorage.removeItem('authToken');
    // this.authService.clearSession();

    this.navCtrl.navigateRoot('/login');
  }
  private clearUserData() {
    // Clear user session data
    localStorage.removeItem('currentUser');
    sessionStorage.clear();
  }

  // --- SPECIALTY LOGIC PIPELINE ---
  public appendNewSpecialtyValue(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    if (!inputElement) return;

    const cleanValue = inputElement.value.trim();
    if (cleanValue && !this.profileData.specialties.includes(cleanValue)) {
      this.profileData.specialties.push(cleanValue);
      inputElement.value = ''; 
    }
  }

  public deleteSpecialty(target: string | number): void {
    if (typeof target === 'number') {
      this.profileData.specialties.splice(target, 1);
    } else {
      this.profileData.specialties = this.profileData.specialties.filter(spec => spec !== target);
    }
  }

  public trackByIndex(index: number, item: any): number {
    return index;
  }

  // --- TAGS LOGIC PIPELINE ---
  public appendNewTagValue(event: Event): void {
    const inputElement = event.target as HTMLInputElement;
    if (!inputElement) return;

    const cleanValue = inputElement.value.trim();
    if (cleanValue && !this.profileData.tags.includes(cleanValue)) {
      this.profileData.tags.push(cleanValue);
      inputElement.value = ''; 
    }
  }

  public deleteTag(tagToDelete: string): void {
    this.profileData.tags = this.profileData.tags.filter(tag => tag !== tagToDelete);
  }

  public triggerUpload(): void {
    alert('Access sequence to device camera library pipeline initiated.');
  }

  public navigateToSlots() {
    this.navCtrl.navigateForward('/slot', {
      state: {
        profile: {
          name: this.profileData.name,
          avatar: this.profileData.avatar,
          mobile: this.profileData.mobile,
          gender: this.profileData.gender,
          email: this.profileData.email
        }
      }
    });
  }

  public goBack() {
    this.navCtrl.navigateBack('/dashboard');
  }

  public navigateToPackages() {
    this.navCtrl.navigateForward('/package');
  }
}