import { Component, OnInit } from '@angular/core';
import { ModalController, NavController } from '@ionic/angular';
import { EditSlotPage } from '../edit-slot/edit-slot.page';
import { AddSlotPage } from '../add-slot/add-slot.page';

interface Slot {
  id: number;
  date: number;
  startTime: string;
  endTime: string;
  status: 'Tej' | 'Rohan' | 'Free' | 'Blocked';
  statusLabel: string;
  type?: string;
}

@Component({
  selector: 'app-slot',
  templateUrl: './slot.page.html',
  styleUrls: ['./slot.page.scss'],
  standalone: false,
})
export class SlotPage implements OnInit {

  selectedDate: number = 17;

  days = [
    { name: 'Mon', date: 16 },
    { name: 'Tue', date: 17 },
    { name: 'Wed', date: 18 },
    { name: 'Thu', date: 19 },
    { name: 'Fri', date: 20 },
    { name: 'Sat', date: 21 },
  ];

  slots: Slot[] = [
    { id: 1, date: 17, startTime: '6:00 AM', endTime: '7:00 AM', status: 'Tej', statusLabel: 'Tej / Deepika', type: 'Personal Training' },
    { id: 2, date: 17, startTime: '7:00 AM', endTime: '8:00 AM', status: 'Free', statusLabel: 'Free' },
    { id: 3, date: 17, startTime: '8:00 AM', endTime: '9:00 AM', status: 'Blocked', statusLabel: 'Blocked' },
    { id: 4, date: 17, startTime: '9:00 AM', endTime: '10:00 AM', status: 'Rohan', statusLabel: 'Rohan S.', type: 'Trial Session' },
  ];

  filteredSlots: Slot[] = [];

  constructor(
    private modalCtrl: ModalController,
    private navCtrl: NavController 
  ) {}

  ngOnInit() {
    this.filterSlots();
  }

  goBack() {
    this.navCtrl.navigateBack('/my-profile'); 
  }

  selectDay(date: number) {
    this.selectedDate = date;
    this.filterSlots();
  }

  filterSlots() {
    this.filteredSlots = this.slots.filter(slot => slot.date === this.selectedDate);
  }

  async openAddSlotModal() {
    const modal = await this.modalCtrl.create({
      component: AddSlotPage,
      cssClass: 'bottom-sheet-modal',
      initialBreakpoint: 0.75,
      breakpoints: [0, 0.55],
      handle: false
    });

    await modal.present();
    const { data } = await modal.onDidDismiss();
    
    if (data && data.slotData) {
      const newSlot: Slot = {
        id: Date.now(),
        date: this.selectedDate,
        startTime: data.slotData.startTime,
        endTime: data.slotData.endTime,
        status: data.slotData.status,
        statusLabel: this.getStatusLabel(data.slotData.status),
        type: this.getStatusType(data.slotData.status)
      };

      this.slots.push(newSlot);
      this.filterSlots();
    }
  }

  async openEditModal(slot: Slot) {
    const modal = await this.modalCtrl.create({
      component: EditSlotPage,
      cssClass: 'bottom-sheet-modal',
      initialBreakpoint: 0.50,
      breakpoints: [0, 0.45],
      handle: false,
      componentProps: {
        currentStatus: slot.status
      }
    });

    await modal.present();
    const { data } = await modal.onDidDismiss();
    
    if (data && data.updatedStatus) {
      const target = this.slots.find(s => s.id === slot.id);
      if (target) {
        target.status = data.updatedStatus;
        target.statusLabel = this.getStatusLabel(data.updatedStatus);
        target.type = this.getStatusType(data.updatedStatus);
        this.filterSlots();
      }
    }
  }

  deleteSlot(id: number) {
    this.slots = this.slots.filter(slot => slot.id !== id);
    this.filterSlots();
  }

  private getStatusLabel(status: 'Tej' | 'Rohan' | 'Free' | 'Blocked'): string {
    if (status === 'Tej') return 'Tej / Deepika';
    if (status === 'Rohan') return 'Rohan S.';
    return status;
  }

  private getStatusType(status: 'Tej' | 'Rohan' | 'Free' | 'Blocked'): string | undefined {
    if (status === 'Tej') return 'Personal Training';
    if (status === 'Rohan') return 'Trial Session';
    return undefined;
  }
}